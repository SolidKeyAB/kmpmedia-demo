
http://192.168.39.134:8000/images/c9d54506-5721-4ded-b0b1-94623e1d7737.jpg

 Method- Post


curl -X POST "http://localhost:8000/upload" -F "file=@/Users/storm/Documents/smiling_style.jpg"

storm@storms-MacBook-Pro Documents % curl -X POST "http://localhost:8000/upload" -F "file=@/Users/storm/Documents/my_photo.jpg" 

(venv-metal) storm@storms-MacBook-Pro simplewebserver % ipconfig getifaddr en0        



curl --location 'https://api.lightxeditor.com/external/api/v1/cartoon' --header 'x-api-key: 6cc2211f4508464b878a4ac65ba72683_d676aea4096c4cc19bec6a06e819c624_andoraitools' --header 'Content-Type: application/json' --data '{"imageUrl": "https://sperm-represents-julie-girl.trycloudflare.com/images/ffcdd483-0123-47ea-a300-953d455888b6.jpg","styleImageUrl": "","textPrompt": "Caricature"}'


{"statusCode":2000,"message":"SUCCESS","body":{"orderId":"733d9a5c3bc84ec5af6e5e70253ad274","maxRetriesAllowed":5,"avgResponseTimeInSec":15,"status":"init"}}%     

curl --location --request POST 'https://api.lightxeditor.com/external/api/v1/order-status' --header 'Content-Type: application/json' --header 'x-api-key: 6cc2211f4508464b878a4ac65ba72683_d676aea4096c4cc19bec6a06e819c624_andoraitools' --data '{"orderId": "b550478b474c49a0bb70a09274f55f4b"}'


curl --location 'https://api.lightxeditor.com/external/api/v1/cartoon' --header 'x-api-key: 6cc2211f4508464b878a4ac65ba72683_d676aea4096c4cc19bec6a06e819c624_andoraitools' --header 'Content-Type: application/json' --data '{"imageUrl": "https://looksmart-subaru-kyle-xl.trycloudflare.com/images/ffcdd483-0123-47ea-a300-953d455888b6.jpg","styleImageUrl": "https://looksmart-subaru-kyle-xl.trycloudflare.com/images/cc3de790-f908-4808-a90e-da10c99f2039.jpg","textPrompt": "Caricature"}'






curl --location 'https://api.lightxeditor.com/external/api/v1/cartoon' --header 'x-api-key: 6cc2211f4508464b878a4ac65ba72683_d676aea4096c4cc19bec6a06e819c624_andoraitools' --header 'Content-Type: application/json' --data '{"imageUrl": "https://almost-capital-eagles-cams.trycloudflare.com/images/22332e38-495c-4104-9909-757ff22c05be.jpg","styleImageUrl": "","textPrompt": "Caricature"}'

curl --location --request POST 'https://api.lightxeditor.com/external/api/v1/order-status' --header 'Content-Type: application/json' --header 'x-api-key: 6cc2211f4508464b878a4ac65ba72683_d676aea4096c4cc19bec6a06e819c624_andoraitools' --data '{"orderId": "d76a1e2e3cf84024915be8c4a23c740f"}'


curl --location 'https://api.lightxeditor.com/external/api/v1/cartoon' --header 'x-api-key: 6cc2211f4508464b878a4ac65ba72683_d676aea4096c4cc19bec6a06e819c624_andoraitools' --header 'Content-Type: application/json' --data '{"imageUrl": "https://ranger-exit-sensors-provisions.trycloudflare.com/images/22332e38-495c-4104-9909-757ff22c05be.jpg","styleImageUrl": "","textPrompt": "Caricature"}'

{imageUrl=https://ranger-exit-sensors-provisions.trycloudflare.com+/images/{"imageUrl":"d70133c9-05a4-4887-b0e1-29cf92a7b021.jpg"}, textPrompt=caricature, styleImageUrl=9a3cf95a-ec51-49a1-9f2d-478eccba79c3.jpg}



{imageUrl=https://ranger-exit-sensors-provisions.trycloudflare.com/images/{"imageUrl":"dbc4665f-9864-4b2b-9f07-4b2db23d3be6.jpg"}, textPrompt=caricature, styleImageUrl=9a3cf95a-ec51-49a1-9f2d-478eccba79c3.jpg}
🔍 Raw API Response: {"status":"FAIL","statusCode":1000,"message":"Oops, Something went wrong. Please try again!","description":"Oops, Something went wrong. Please try again!","timestamp":1737371552047,"responseHash":null,"body":null}
❌ Failed to get Order ID. Exiting requestProcessingResult.




(venv-metal) storm@storms-MacBook-Pro simplewebserver % podman build -t fastapi-app .

(venv-metal) storm@storms-MacBook-Pro simplewebserver % podman ps                
CONTAINER ID  IMAGE                         COMMAND               CREATED        STATUS        PORTS                   NAMES
4c3d6ceda299  localhost/fastapi-app:latest  uvicorn main:app ...  5 minutes ago  Up 5 minutes  0.0.0.0:8000->8000/tcp  fastapi-container
(venv-metal) storm@storms-MacBook-Pro simplewebserver % podman rm -f 4c3d6ceda299
4c3d6ceda299
(venv-metal) storm@storms-MacBook-Pro simplewebserver % podman run --name fastapi-container -p 8000:8000 --rm -d fastapi-app
a7a853337fc9e64a3e4ad66031c01cace1c2ff176a3f41c2f344a6164aa18e80
(venv-metal) storm@storms-MacBook-Pro simplewebserver % podman logs -f fastapi-container


curl -X POST "https://ranger-exit-sensors-provisions.trycloudflare.com/upload" \
     -F "file=@/Users/storm/Documents/smiling_style.jpg"




curl -X POST "https://api.lightxeditor.com/external/api/v2/uploadImageUrl/preprod" \
     -H "Content-Type: application/json" \
     -H "x-api-key: 6cc2211f4508464b878a4ac65ba72683_d676aea4096c4cc19bec6a06e819c624_andoraitools" \
     -d '{"uploadType": "imageUrl", "size": 5156110, "contentType": "image/jpeg"}'


curl -v -X POST "https://api.lightxeditor.com/external/api/v2/uploadImageUrl/preprod" \
     -H "Content-Type: application/json" \
     -H "x-api-key: 6cc2211f4508464b878a4ac65ba72683_d676aea4096c4cc19bec6a06e819c624_andoraitools" \
     -d '{"uploadType": "imageUrl", "size": 123456, "contentType": "image/jpeg"}'







curl -X POST "https://api.lightxeditor.com/external/api/v2/uploadImageUrl/preprod" \
     -H "Content-Type: application/json" \
     -H "x-api-key: 6cc2211f4508464b878a4ac65ba72683_d676aea4096c4cc19bec6a06e819c624_andoraitools" \
     -d '{"uploadType": "imageUrl", "size": 5156110, "contentType": "image/jpeg"}'