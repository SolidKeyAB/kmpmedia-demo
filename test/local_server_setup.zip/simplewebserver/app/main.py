from fastapi import FastAPI, File, UploadFile
from fastapi.responses import FileResponse
import shutil
import os
import uuid
import re
from datetime import datetime

# Configuration
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = FastAPI()

@app.get("/ping")
def ping():
    return {"status": "ok"}

# 1️⃣ Upload image from mobile app
@app.post("/upload")  # Remove the trailing slash
async def upload_image(file: UploadFile = File(...)):
    file_extension = file.filename.split(".")[-1]
    unique_filename = f"{uuid.uuid4()}.{file_extension}"
    file_path = os.path.join(UPLOAD_FOLDER, unique_filename)

    now = datetime.now()
    formatted_time = now.strftime("%Y-%m-%d %H:%M:%S")
    print(f"📂 {formatted_time} Saving file to: {file_path}")  # Debugging line

    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    return {"imageUrl": f"{unique_filename}"}


# 2️⃣ Serve image for AI API (LightXEditor)
@app.get("/images/{filename}")
async def get_image(filename: str):
    # Allow only filenames with alphanumeric, hyphens, and underscores
    if not re.match(r"^[a-zA-Z0-9_-]+\.(jpg|png|jpeg)$", filename):
        raise HTTPException(status_code=400, detail="Invalid filename")

    file_path = os.path.join(UPLOAD_FOLDER, filename)
    if os.path.exists(file_path):
        now = datetime.now()
        formatted_time = now.strftime("%Y-%m-%d %H:%M:%S")
        print(f"📂 {formatted_time} File request from AI service: {file_path}")

        return FileResponse(file_path, media_type="image/jpeg")
    return {"error": "File not found"}
