# Local Test Setup:

1. Podman container running Web simplewebserver
2. Tunnel service (Cloudflare)

All the required code is inside this zip file.

Just follow these steps:

1. Extract zip to a folder

### Terminal-1:

1. Go to the folder
2. 

```bash
   podman machine init                                                 
   podman machine start  // This may not be needed
   podman build -t fastapi-app .
   podman run --name fastapi-container -p 8000:8000 --rm -d fastapi-app
```

3. To see the logs from container:



```bash
   podman logs -f fastapi-container
```

### Terminal-2:

1.
```bash
   cloudflared tunnel --url http://localhost:8000
```

2. Copy the URL like below (https://xhtml-conferences-profiles-alpine.trycloudflare.com) and that is your tunnel URL that will represent your IP address. Then use as the value of variable (WEB_SERVER_TUNNEL_URL) in your APP 

```bash
2025-01-23T12:45:20Z INF Requesting new quick Tunnel on trycloudflare.com...
2025-01-23T12:45:25Z INF +--------------------------------------------------------------------------------------------+
2025-01-23T12:45:25Z INF |  Your quick Tunnel has been created! Visit it at (it may take some time to be reachable):  |
2025-01-23T12:45:25Z INF |  https://xhtml-conferences-profiles-alpine.trycloudflare.com                               |
2025-01-23T12:45:25Z INF +--------------------------------------------------------------------------------------------+
2025-01-23T12:45:25Z INF Cannot determine default configuration path. No file [config.yml config.yaml] in [~/.cloudflared ~/.
```
