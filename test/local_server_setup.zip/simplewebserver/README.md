# FOR TESTING WITH LOCAL SERVER:
  Refer to Local_Server_Setup.md


# For curl trials:
  Refer to Notes.md